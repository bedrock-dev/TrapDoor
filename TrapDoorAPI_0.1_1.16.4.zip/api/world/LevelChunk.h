//
// Created by xhy on 2020/11/9.
//

#ifndef TRAPDOOR_LEVELCHUNK_H
#define TRAPDOOR_LEVELCHUNK_H

namespace trapdoor {
    class LevelChunk {

    };
}


#endif //TRAPDOOR_LEVELCHUNK_H
