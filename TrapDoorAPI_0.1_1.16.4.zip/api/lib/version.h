const char trapDoorVersion[] = "Trapdoor V0.6.0-debug";
const char developers[] = "hhhxiao OEOTYAN";
const char credits[] = "";
const char minecraftVersion[] = "1.16.4.0";