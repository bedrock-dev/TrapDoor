## 免责声明

trapdoor-mod(以下简称td)是一个利用dll远程注入技术开发的BDS辅助插件，它提供了不少
方便玩家的功能，给生电玩家创造了便利。

除此之外，td本身是开源免费的，内部没有任何恶意代码，原则上也不会对存档造成任何损害。

但是考虑到此类软件的特殊性，开发者也不能完全保证td对用户的存档不造成任何破坏，万一发生
意外情况，开发者不会也没有能力对td对用户造成的损失负责。

如果你继续使用td插件，那么就代表你同意了该声明(或者说叫用户协议)，如果你不想承担此类
风险，请停止使用td插件。

附录：
以下是一些使用建议:
 - 及时更新插件到新版本，因为目前td还是beta版，越更新bug肯方定会越少
 - 尽量关闭不用的功能
 - 及时备份存档永远是好习惯

2021.1.23

## Disclaimer

trapdoor-mod (hereinafter referred to as td) is a BDS auxiliary plug-in developed by dll remote injection technology,
which provides many functions that are convenient for players.

In addition, td itself is open source and free, there is no malicious code inside, and in principle it will not cause
any damage to the archive.

However, considering the particularity of such software, the developer cannot completely guarantee that td will not
cause any damage to the user's level, in case it happens. In unexpected circumstances, developers will not and cannot
be responsible for the losses caused by td to users.

If you continue to use the td plug-in, then by default you agree to this disclaimer(or user agreement), if you do not
want to bear such risk, please stop using td plugin.

appendix:
Here are some suggestions for use:
  - Update the plug-in to the new version in time, because the td is still a beta version, the more you update it, the
    less bugs you can expect
  - Try to turn off unused functions
  - Timely backup and archive is always a good habit

2021.1.23